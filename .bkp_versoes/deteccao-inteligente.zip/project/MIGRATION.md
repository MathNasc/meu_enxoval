# Detecção Inteligente de Produtos — Guia de Migração

## O que mudou

### Feature renomeada
- ❌ "Scraping automático" → ✅ "Detecção inteligente"
- ❌ `extractProduct` → ✅ `detectProduct`
- ❌ `/api/extract-product` → ✅ `/api/detect-product`

> **Nota:** `extractProduct` ainda funciona (deprecated) — aponta para o novo endpoint.

---

## Estrutura de arquivos novos

```
lib/product-detection/
  index.js                      ← Orquestrador principal
  resolveUrl.js                 ← Resolve encurtadores (br.shp.ee, amzn.to, etc.)
  extractors/
    shopee.js                   ← API mobile + scraping + fallback URL
    mercadolivre.js             ← API oficial + search + scraping + fallback URL
    amazon.js                   ← Scraping com JSON-LD + CSS selectors
    generic.js                  ← Fallback universal (JSON-LD + OG tags + h1)
  utils/
    cleanName.js                ← Remove sufixos de loja e textos inválidos
    parsePrice.js               ← Converte strings BRL em float
    guessRoom.js                ← Infere cômodo pelo nome do produto
    security.js                 ← Validação SSRF

app/api/detect-product/
  route.js                      ← Novo handler (substitui extract-product)

src/lib/services/
  api.js                        ← Atualizado com detectProduct()

src/components/modals/
  QuickAddModal.jsx             ← Atualizado com nova nomenclatura e UX
```

---

## Como adicionar uma nova plataforma

1. Crie `lib/product-detection/extractors/novaLoja.js`:

```js
import { cleanName } from "../utils/cleanName.js";
import { parsePrice } from "../utils/parsePrice.js";

export async function novaLojaExtractor(url) {
  // sua lógica aqui
  return { name, price, imageUrl, brand, store: "Nova Loja" };
}
```

2. Registre em `lib/product-detection/index.js`:

```js
import { novaLojaExtractor } from "./extractors/novaLoja.js";

const EXTRACTORS = [
  // ... extractors existentes ...
  {
    name: "Nova Loja",
    match: (h) => h.includes("novaloja.com.br"),
    fn: novaLojaExtractor,
  },
  { name: "Genérico", match: () => true, fn: genericExtractor }, // sempre por último
];
```

---

## Links encurtados suportados

O `resolveUrl.js` suporta qualquer encurtador via seguimento de redirects HTTP.
Encurtadores explicitamente reconhecidos (força resolução mesmo em domínio "desconhecido"):

- `br.shp.ee` / `shp.ee` (Shopee)
- `amzn.to` (Amazon)
- `meli.me` / `mercadolivre.page.link` (Mercado Livre)
- `bit.ly`, `tinyurl.com`, `t.co`, `goo.gl`
- `ow.ly`, `rb.gy`, `cutt.ly`, `s.id`, `buff.ly`

---

## Passos de migração no projeto

1. Copie os arquivos desta pasta para a raiz do projeto mantendo a estrutura
2. Remova (ou mantenha deprecated) `/app/api/extract-product/route.js`
3. Os componentes que usam `AI.extractProduct()` funcionarão automaticamente via alias
4. Para usar a nova API explicitamente: substitua por `AI.detectProduct()`
