/**
 * Service Worker — Meu Enxoval PWA
 *
 * Estratégia: Network First com fallback para cache.
 * - Assets estáticos (ícones, CSS, JS): Cache First
 * - Páginas e API: Network First → cache offline
 * - Supabase API: sempre Network (não cachear dados)
 */

const CACHE_VERSION = "v1";
const CACHE_STATIC  = `enxoval-static-${CACHE_VERSION}`;
const CACHE_PAGES   = `enxoval-pages-${CACHE_VERSION}`;

// Assets que sempre ficam em cache
const PRECACHE_URLS = [
  "/",
  "/manifest.json",
  "/icons/icon-192x192.png",
  "/icons/icon-512x512.png",
];

// ── Install ─────────────────────────────────────────────
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_STATIC).then((cache) => {
      return cache.addAll(PRECACHE_URLS);
    }).then(() => self.skipWaiting())
  );
});

// ── Activate ────────────────────────────────────────────
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k.startsWith("enxoval-") && !k.endsWith(CACHE_VERSION))
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ── Fetch ────────────────────────────────────────────────
self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Nunca interceptar: Supabase, APIs externas, autenticação
  if (
    url.hostname.includes("supabase.co") ||
    url.hostname.includes("supabase.com") ||
    url.pathname.startsWith("/api/") ||
    request.method !== "GET"
  ) {
    return; // deixa o browser lidar normalmente
  }

  // Static assets (ícones, imagens, fontes) → Cache First
  if (
    url.pathname.startsWith("/icons/") ||
    url.pathname.match(/\.(png|jpg|svg|ico|woff2?|ttf)$/)
  ) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((response) => {
          const clone = response.clone();
          caches.open(CACHE_STATIC).then((c) => c.put(request, clone));
          return response;
        });
      })
    );
    return;
  }

  // Next.js _next/static → Cache First (imutável por hash)
  if (url.pathname.startsWith("/_next/static/")) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((response) => {
          const clone = response.clone();
          caches.open(CACHE_STATIC).then((c) => c.put(request, clone));
          return response;
        });
      })
    );
    return;
  }

  // Páginas HTML → Network First, fallback para cache
  event.respondWith(
    fetch(request)
      .then((response) => {
        const clone = response.clone();
        caches.open(CACHE_PAGES).then((c) => c.put(request, clone));
        return response;
      })
      .catch(() =>
        caches.match(request).then(
          (cached) => cached || caches.match("/")
        )
      )
  );
});

// ── Background Sync (para quando voltar online) ──────────
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-items") {
    // Future: sincronizar items pendentes offline
    console.log("[SW] Background sync triggered");
  }
});
