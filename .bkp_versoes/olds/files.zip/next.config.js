/** @type {import('next').NextConfig} */
const nextConfig = {
  // Permite importar o App.js com JSX no src/
  experimental: {
    // necessário para usar JSX em .js sem renomear para .jsx
  },
};

module.exports = nextConfig;
