/**
 * POST /api/compare-prices
 * Body: { productName: string }
 *
 * Busca preços em múltiplas lojas usando o Zoom.com.br
 * (agregador gratuito: Amazon, ML, Shopee, Magalu, etc.)
 * Sem nenhuma API key necessária.
 */

import axios from "axios";
import * as cheerio from "cheerio";

const BROWSER_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "pt-BR,pt;q=0.9",
  "Cache-Control": "no-cache",
};

/* ─── Parsers de preço ─── */
function parsePrice(str) {
  if (!str) return 0;
  const cleaned = str
    .replace(/[^\d,\.]/g, "")
    .replace(/\.(?=\d{3})/g, "") // remove ponto de milhar
    .replace(",", ".");            // vírgula → ponto decimal
  const n = parseFloat(cleaned);
  return isNaN(n) ? 0 : n;
}

/* ─── Estratégia 1: Zoom.com.br ─── */
async function scrapeZoom(productName) {
  const q = encodeURIComponent(productName);
  const url = `https://www.zoom.com.br/search?q=${q}`;

  const { data: html } = await axios.get(url, {
    headers: BROWSER_HEADERS,
    timeout: 10_000,
  });

  const $ = cheerio.load(html);
  const offers = [];

  // Zoom usa diferentes estruturas conforme versão do layout
  const cardSelectors = [
    '[class*="ProductCard"]',
    '[class*="productCard"]',
    '[data-testid*="product"]',
    'article[class*="product"]',
    '.product-card',
  ];

  let found = false;
  for (const sel of cardSelectors) {
    const cards = $(sel);
    if (!cards.length) continue;
    found = true;

    cards.each((i, el) => {
      if (i >= 8) return;
      const card = $(el);

      const name = card.find("h2, h3, [class*='title'], [class*='name']").first().text().trim();
      const priceText = card.find("[class*='price'], [class*='Price'], [class*='preco']").first().text().trim();
      const store = card.find("[class*='store'], [class*='Store'], [class*='loja']").first().text().trim();
      const link = card.find("a").first().attr("href");
      const image = card.find("img").first().attr("src") || card.find("img").first().attr("data-src");

      const price = parsePrice(priceText);
      if (price > 0) {
        offers.push({
          store:   store || "Zoom",
          price,
          url:     link ? (link.startsWith("http") ? link : `https://www.zoom.com.br${link}`) : url,
          image:   image || null,
          inStock: true,
          source:  "zoom",
        });
      }
    });
    break;
  }

  return offers;
}

/* ─── Estratégia 2: Buscapé ─── */
async function scrapeBuscape(productName) {
  const q = encodeURIComponent(productName);
  const url = `https://www.buscape.com.br/search?q=${q}`;

  const { data: html } = await axios.get(url, {
    headers: BROWSER_HEADERS,
    timeout: 10_000,
  });

  const $ = cheerio.load(html);
  const offers = [];

  $("[class*='ProductCard'], [class*='product-card'], article").each((i, el) => {
    if (i >= 8) return;
    const card = $(el);

    const priceText = card.find("[class*='price'], [class*='Price']").first().text().trim();
    const store     = card.find("[class*='seller'], [class*='store'], [class*='Shop']").first().text().trim();
    const link      = card.find("a").first().attr("href");
    const image     = card.find("img").first().attr("src");

    const price = parsePrice(priceText);
    if (price > 0) {
      offers.push({
        store:   store || "Buscapé",
        price,
        url:     link ? (link.startsWith("http") ? link : `https://www.buscape.com.br${link}`) : url,
        image:   image || null,
        inStock: true,
        source:  "buscape",
      });
    }
  });

  return offers;
}

/* ─── Estratégia 3: Google Shopping embed (fallback) ─── */
async function scrapeGoogleShopping(productName) {
  const q = encodeURIComponent(`${productName} comprar`);
  const url = `https://www.google.com.br/search?q=${q}&tbm=shop&gl=br&hl=pt-BR`;

  const { data: html } = await axios.get(url, {
    headers: {
      ...BROWSER_HEADERS,
      "Accept": "text/html",
    },
    timeout: 10_000,
  });

  const $ = cheerio.load(html);
  const offers = [];

  // Google Shopping results
  $(".sh-dgr__content, .KZmu8e, [class*='sh-pr']").each((i, el) => {
    if (i >= 6) return;
    const card = $(el);

    const store     = card.find(".aULzUe, .E5ocAb, [class*='merchant']").first().text().trim();
    const priceText = card.find(".HRLxBb, .a8Pemb, [class*='price']").first().text().trim();
    const link      = card.find("a").first().attr("href");
    const image     = card.find("img").first().attr("src");

    const price = parsePrice(priceText);
    if (price > 0 && store) {
      offers.push({
        store,
        price,
        url:     link || "",
        image:   image || null,
        inStock: true,
        source:  "google",
      });
    }
  });

  return offers;
}

/* ─── Deduplicar e ordenar ─── */
function dedupeAndSort(offers) {
  const seen = new Set();
  return offers
    .filter(o => {
      if (!o.price || o.price <= 0) return false;
      const key = `${o.store}-${o.price}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => a.price - b.price)
    .slice(0, 6);
}

/* ─── Handler principal ─── */
export async function POST(req) {
  let productName;
  try {
    ({ productName } = await req.json());
  } catch {
    return Response.json({ error: "Body inválido" }, { status: 400 });
  }

  if (!productName?.trim()) {
    return Response.json({ error: "Nome do produto obrigatório" }, { status: 400 });
  }

  const errors = [];
  let allOffers = [];

  // Tenta Zoom primeiro (mais completo para BR)
  try {
    const zoomOffers = await scrapeZoom(productName);
    allOffers.push(...zoomOffers);
  } catch (e) {
    errors.push(`Zoom: ${e.message}`);
  }

  // Se Zoom não retornou nada, tenta Buscapé
  if (allOffers.length === 0) {
    try {
      const buscapeOffers = await scrapeBuscape(productName);
      allOffers.push(...buscapeOffers);
    } catch (e) {
      errors.push(`Buscapé: ${e.message}`);
    }
  }

  // Fallback Google Shopping
  if (allOffers.length === 0) {
    try {
      const googleOffers = await scrapeGoogleShopping(productName);
      allOffers.push(...googleOffers);
    } catch (e) {
      errors.push(`Google: ${e.message}`);
    }
  }

  const offers = dedupeAndSort(allOffers);

  console.log(`[compare-prices] "${productName}" → ${offers.length} ofertas encontradas`);

  return Response.json({
    offers,
    debug: process.env.NODE_ENV === "development" ? { errors } : undefined,
  });
}
