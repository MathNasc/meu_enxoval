/**
 * POST /api/extract-product
 * Body: { url: string }
 *
 * Extrai nome, preço, imagem e cômodo sugerido de qualquer
 * e-commerce brasileiro usando Open Graph + cheerio.
 * Funciona com: Amazon, Mercado Livre, Shopee, Magalu,
 *               Casas Bahia, Americanas, Leroy Merlin, etc.
 */

import axios from "axios";
import * as cheerio from "cheerio";

/* ─── Headers que simulam um navegador real ─── */
const BROWSER_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
  "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
  "Accept-Encoding": "gzip, deflate, br",
  "Cache-Control": "no-cache",
  "Pragma": "no-cache",
};

/* ─── Seletores de preço por loja ─── */
const PRICE_SELECTORS = [
  // Meta tags (mais confiáveis)
  'meta[property="product:price:amount"]',
  'meta[property="og:price:amount"]',
  'meta[itemprop="price"]',
  'meta[name="price"]',
  // Amazon
  ".a-price-whole",
  ".priceToPay .a-price-whole",
  "#priceblock_ourprice",
  "#priceblock_dealprice",
  // Mercado Livre
  ".andes-money-amount__fraction",
  ".ui-pdp-price__second-line .andes-money-amount__fraction",
  // Magalu
  '[data-testid="price-value"]',
  ".sc-dRFtgE",
  // Shopee
  "._3n5NQx",
  ".pqTWkA",
  // Casas Bahia / Extra
  ".product-price",
  ".priceDetail-sellingPrice",
  // Genéricos
  '[class*="price"]',
  '[id*="price"]',
  '[class*="preco"]',
  '[id*="preco"]',
  ".price",
  ".valor",
];

/* ─── Seletores de imagem ─── */
const IMAGE_SELECTORS = [
  'meta[property="og:image"]',
  'meta[name="twitter:image"]',
  'meta[property="og:image:url"]',
  'meta[property="og:image:secure_url"]',
  'link[rel="image_src"]',
];

/* ─── Seletores de título ─── */
const TITLE_SELECTORS = [
  'meta[property="og:title"]',
  'meta[name="twitter:title"]',
  'meta[name="title"]',
  'meta[property="og:site_name"]',
];

/* ─── Helpers ─── */
function getMeta($, selectors) {
  for (const sel of selectors) {
    const el = $(sel).first();
    const val =
      el.attr("content") ||
      el.attr("href") ||
      el.text().trim();
    if (val && val.trim()) return val.trim();
  }
  return null;
}

function extractPrice($) {
  // 1. Tenta meta tags primeiro
  for (const sel of PRICE_SELECTORS.slice(0, 4)) {
    const val = $(sel).attr("content");
    if (val) {
      const n = parseFloat(val.replace(/[^\d.,]/g, "").replace(",", "."));
      if (!isNaN(n) && n > 0) return n;
    }
  }

  // 2. Tenta elementos HTML — pega o texto e extrai valor em R$
  for (const sel of PRICE_SELECTORS.slice(4)) {
    const text = $(sel).first().text().replace(/\s+/g, " ").trim();
    if (!text) continue;

    // Procura padrão R$ XX,XX ou XX.XX,XX
    const patterns = [
      /R\$\s*([\d.]+,\d{2})/,
      /R\$\s*([\d]+)/,
      /([\d]{1,3}(?:\.[\d]{3})*,\d{2})/,
      /([\d]+[.,]\d{2})/,
    ];

    for (const pat of patterns) {
      const m = text.match(pat);
      if (m) {
        const cleaned = m[1]
          .replace(/\./g, "")  // remove separador de milhar
          .replace(",", ".");   // vírgula → ponto decimal
        const n = parseFloat(cleaned);
        if (!isNaN(n) && n > 0 && n < 1_000_000) return n;
      }
    }
  }

  return null;
}

function extractTitle($) {
  // 1. Meta tags
  const meta = getMeta($, TITLE_SELECTORS);
  if (meta) return cleanTitle(meta);

  // 2. <h1> da página
  const h1 = $("h1").first().text().trim();
  if (h1 && h1.length > 3) return cleanTitle(h1);

  // 3. <title> tag
  const title = $("title").text().trim();
  if (title) return cleanTitle(title);

  return null;
}

function cleanTitle(str) {
  if (!str) return null;
  // Remove sufixos comuns de e-commerce
  return str
    .replace(/\s*[-|–]\s*.*(Amazon|Mercado|Shopee|Magalu|Americanas|Casas Bahia|Extra).*$/i, "")
    .replace(/\s*\|\s*.*$/, "")
    .trim()
    .slice(0, 200);
}

function guessRoom(name) {
  if (!name) return "outro";
  const n = name.toLowerCase();

  const map = [
    { room: "sala",     words: /sofá|sofa|rack|tapete.*sala|poltrona|estante|home theater|tv\b|televisão|mesa.*sala|aparador|luminária/ },
    { room: "quarto",   words: /cama\b|colchão|cabeceira|guarda.roupa|cômoda|criado.mudo|travesseiro|edredom|lençol|cobertor|roupa.*cama/ },
    { room: "cozinha",  words: /panela|frigideira|geladeira|fogão|micro.ondas|liquidificador|batedeira|airfryer|escorredor|prato|talher|copo|caneca|garrafa.*água|lixeira.*coz|tábua.*corte/ },
    { room: "banheiro", words: /toalha|tapete.*banheiro|saboneteira|box|vaso.*sanitário|cuba|torneira|shampoo|condicionador|espelho.*banheiro/ },
  ];

  for (const { room, words } of map) {
    if (words.test(n)) return room;
  }
  return "outro";
}

function extractBrand($) {
  const selectors = [
    'meta[property="og:brand"]',
    'meta[itemprop="brand"]',
    '[itemprop="brand"] [itemprop="name"]',
    '[class*="brand"]',
    '[class*="marca"]',
  ];
  return getMeta($, selectors);
}

/* ─── Handler principal ─── */
export async function POST(req) {
  let url;
  try {
    ({ url } = await req.json());
  } catch {
    return Response.json({ error: "Body inválido" }, { status: 400 });
  }

  if (!url || !url.startsWith("http")) {
    return Response.json({ error: "URL inválida" }, { status: 400 });
  }

  try {
    const { data: html } = await axios.get(url, {
      headers: BROWSER_HEADERS,
      timeout: 10_000,
      maxRedirects: 5,
      // Desativa verificação SSL para sites com cert inválido
      httpsAgent: new (await import("https")).Agent({ rejectUnauthorized: false }),
    });

    const $ = cheerio.load(html);

    const name        = extractTitle($);
    const price       = extractPrice($);
    const imageUrl    = getMeta($, IMAGE_SELECTORS);
    const brand       = extractBrand($);
    const suggestedRoom = guessRoom(name);

    return Response.json({ name, price, imageUrl, brand, suggestedRoom });

  } catch (err) {
    console.error("[extract-product]", err.message);

    // Retorna erro estruturado para o frontend tratar
    const status = err.response?.status || 500;
    return Response.json(
      { error: "Não foi possível acessar o produto", detail: err.message },
      { status }
    );
  }
}
