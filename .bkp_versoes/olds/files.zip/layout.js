export const metadata = {
  title: "Enxoval",
  description: "Organize o enxoval do seu apartamento",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
